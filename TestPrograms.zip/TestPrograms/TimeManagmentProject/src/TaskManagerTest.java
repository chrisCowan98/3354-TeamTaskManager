import org.junit.Test;
import static org.junit.Assert.*;
import java.time.LocalDate;


public class TaskManagerTest {
	
	@Test
	public void testTaskPriorityWithSameUrgecyAndDueDate() {
		TaskManager manager = new TaskManager();
        Task taskA = new Task("Task A", LocalDate.now().plusDays(2).toString(), "10:00", 3);
        Task taskB = new Task("Task B", LocalDate.now().plusDays(2).toString(), "11:00", 3);
        Task taskC = new Task("Task C", LocalDate.now().plusDays(2).toString(), "12:00", 3);

        manager.addTask(taskB);
        manager.addTask(taskC);
        manager.addTask(taskA);

        assertEquals("Task A should be first alphabetically", taskA, manager.getNextTask());
        assertEquals("Task B should be next alphabetically", taskB, manager.getNextTask());
        assertEquals("Task C should be last alphabetically", taskC, manager.getNextTask());
	}
	
	@Test
	public void testTaskPriorityWithDifferentUrgencyAndDueDate() {
		TaskManager manager = new TaskManager();
		Task taskA = new Task("Task A", LocalDate.now().plusDays(6).toString(), "10:00", 5);
        Task taskB = new Task("Task B", LocalDate.now().plusDays(15).toString(), "11:00", 2);
        Task taskC = new Task("Task C", LocalDate.now().plusDays(7).toString(), "12:00", 9);
        
        manager.addTask(taskA);
        manager.addTask(taskB);
        manager.addTask(taskC);
        
        assertEquals("Task C should be first (First Highest Urgency)", taskC, manager.getNextTask());
        assertEquals("Task A should be second (Second Highest Urgency)", taskA, manager.getNextTask());
        assertEquals("Task B should be second (Third Highest Urgency)", taskB, manager.getNextTask());

	}
	
	@Test
    public void testTaskPriorityWithSameUrgencyDifferentDueDate() {
        TaskManager manager = new TaskManager();
        Task taskA = new Task("Task A", LocalDate.now().plusDays(5).toString(), "10:00", 3);
        Task taskB = new Task("Task B", LocalDate.now().plusDays(3).toString(), "11:00", 3);
        Task taskC = new Task("Task C", LocalDate.now().plusDays(7).toString(), "12:00", 3);

        manager.addTask(taskA);
        manager.addTask(taskB);
        manager.addTask(taskC);

        assertEquals("Task B should be first (earliest due date)", taskB, manager.getNextTask());
        assertEquals("Task A should be second (second earliest due date)", taskA, manager.getNextTask());
        assertEquals("Task C should be last (latest due date)", taskC, manager.getNextTask());
    }
	
}
