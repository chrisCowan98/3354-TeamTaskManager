import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.temporal.ChronoUnit;

public class Task {
	// Data field 
	private String title;
	private String dueDate;
	private boolean completion;
	private String time;
	private int complexity;
	private int urgency;
	private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    private static final DateTimeFormatter TIME_FORMATTER = DateTimeFormatter.ofPattern("HH:mm");
	
	public Task(String title, String dueDate, String time, int complexity) {
		this.title = title;
		this.setDueDate(dueDate);
		this.setCompletion(completion);
		this.setTime(time);
		this.setComplexity(complexity);
		this.calculateUrgency();
	}
	// Urgency Method
	public int calculateUrgency() {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		LocalDate today = LocalDate.now();
		LocalDate dueDate = LocalDate.parse(this.dueDate, formatter);
		
		long daysUntilDue = ChronoUnit.DAYS.between(today,  dueDate);
		
		urgency = (complexity * 100) / (int) (daysUntilDue + 1); // Plus 1 to avoid / 0 error
		
		if (urgency > 100) urgency = 100;
		if (urgency < 0) urgency = 0;
		
		return urgency; 
	}
	// Setters
	public void setComplexity(int complexity) {
		this.complexity = complexity;
		if(complexity > 10) complexity = 10;
		if(complexity < 0) complexity = 0;
	}
	public void setCompletion(boolean compleation) {
		this.completion = compleation;
	}
	public void setDueDate(String dueDate) {
		this.dueDate = dueDate;
		try {
			LocalDate.parse(dueDate, DATE_FORMATTER);
			this.dueDate = dueDate;
		} catch (DateTimeParseException e) {
			throw new IllegalArgumentException("Due date must be in the format yyyy-MM-dd");
		}
	}
	public void setTime(String time) {
        try {
            LocalTime.parse(time, TIME_FORMATTER);
            this.time = time;
        } catch (DateTimeParseException e) {
            throw new IllegalArgumentException("Time must be in the format HH:mm (24-hour time).");
        }
    }
	// Getters
    public String getTitle() {
        return title;
    }

    public String getDueDate() {
        return dueDate;
    }

    public boolean isCompletion() {
        return completion;
    }

    public String getTime() {
        return time;
    }

    public int getComplexity() {
        return complexity;
    }

    public int getUrgency() {
        return urgency;
    }
	@Override
	public String toString() {
		return "Task{" +
		       "title='" + title + '\'' +
		       ", dueDate='" + dueDate + '\'' +
		       ", completion=" + completion +
		       ", time='" + time + '\'' +
		       ", complexity=" + complexity +
		       ", urgency=" + urgency +
		       '}';
	}
}
