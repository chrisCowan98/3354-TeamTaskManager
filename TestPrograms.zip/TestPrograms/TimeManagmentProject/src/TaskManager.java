import java.util.*;
import java.util.Comparator;

public class TaskManager {
private PriorityQueue<Task> taskQueue;
	
	public TaskManager() {
		this.taskQueue = new PriorityQueue<>(new TaskComparator());
	}
	
	public void addTask(Task task) {
		taskQueue.add(task);
	}
	
	public Task getNextTask() {
		return taskQueue.poll();
	}
	
	public int getQueueSize() {
		return taskQueue.size();
	}
	
	private static class TaskComparator implements Comparator<Task> {

		@Override
		public int compare(Task t1, Task t2) {
			if (t1.calculateUrgency() != t2.calculateUrgency()) {
				return Integer.compare(t2.calculateUrgency(), t1.calculateUrgency());
			} else if (!t1.getDueDate().equals(t2.getDueDate())) {
				return t1.getDueDate().compareTo(t2.getDueDate());
			} else {
				return t1.getTitle().compareTo(t2.getTitle());
			} 
		}
	}
}
