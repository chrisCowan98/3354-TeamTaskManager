import static org.junit.Assert.assertEquals;

import java.time.LocalDate;

import org.junit.Test;

public class TaskTest {
	// Calculation test case
	@Test
	public void testCalculateUrgency_FutureDueDate() {
		// Test urgency calculation for a task with a moderate complexity (5) due in 8 days.
		Task task = new Task("Future Task", LocalDate.now().plusDays(8).toString(), "12:00", 5);
		int expectedUrgency = (5 * 100) / (8 + 1); 
		assertEquals("Urgency should match calculated level for a future due date.", expectedUrgency, task.calculateUrgency());
	}
	// Upper bound edge case
	@Test
	public void testCalculateUrgency_UrgencyMaxAt100() {
        // Test urgency calculation with high complexity (12) and a due date in 7 days.
		Task task = new Task("High Urgency Task", LocalDate.now().plusDays(7).toString(), "14:00", 12);
		int expectedUrgency = 100;
		assertEquals("Urgency should cap at 100.", expectedUrgency, task.calculateUrgency());
	}
	// High test case
	@Test
	public void testCalculateUrgency_HighUrgency() {
        // Test urgency calculation with high complexity (12) and a due date in 7 days.
		Task task = new Task("High Urgency Task", LocalDate.now().plusDays(8).toString(), "14:00", 8);
		int expectedUrgency = (8 * 100) / (8 + 1);
		assertEquals("Urgency should cap at 100.", expectedUrgency, task.calculateUrgency());
	}
	// Low test case
	@Test
	public void testCalculateUrgency_LowUrgency() {
        // Test urgency calculation with low complexity (3) and a longer due date of 14 days.
		Task task = new Task("Low Urgency Task", LocalDate.now().plusDays(14).toString(), "15:00", 3);
		int expectedUrgency = 20;
	    assertEquals("Urgency should be low.", expectedUrgency, task.calculateUrgency());
	}
	// Lower bound edge case
	@Test
	public void testCalculateUrgency_UrgencyMinAt0() {
        // Test urgency calculation with low complexity (0) and a longer due date of 5 days.
		Task task = new Task("Low Urgency Task", LocalDate.now().plusDays(5).toString(), "15:00", 0);
		int expectedUrgency = 0;
	    assertEquals("Urgency should be zero.", expectedUrgency, task.calculateUrgency());
	}
}